alias brews='brew list -1'
alias bubu="brew update && brew upgrade && brew cleanup"
