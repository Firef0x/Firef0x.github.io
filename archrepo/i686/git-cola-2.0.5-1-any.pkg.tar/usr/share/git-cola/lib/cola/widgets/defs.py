no_margin = 0
small_margin = 2
margin = 4
no_spacing = 0
spacing = 4
handle_width = 4
button_spacing = 12
