# The current git-cola version
VERSION = '2.0.5'
