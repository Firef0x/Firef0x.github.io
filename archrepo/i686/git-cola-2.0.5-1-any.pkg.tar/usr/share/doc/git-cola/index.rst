======================
Git Cola Documentation
======================
.. toctree::

    git-cola
    git-dag
    thanks

Release Notes
=============
.. toctree::
    :maxdepth: 1

    relnotes

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
