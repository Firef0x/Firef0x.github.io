Thanks
======
`git-cola` was made possible thanks to the contributions of the following people:

* Aaron Cook
* Alex Chernetz
* Alexander Kozienko
* Andreas Sommer
* Audrius Karabanovas
* Barry Roberts
* Boris W
* Ben Boeckel
* Ben Cole
* Benoît Nouyrigat
* Charles 101
* Christian Jann
* Christopher Meng
* Daniel Fahlke
* Daniel Harding
* Daniel King
* David Aguilar
* David Martínez Martí
* Dennis Gilmore
* Eric Drechsel
* `GIT Hackers <http://git-scm.com/about>`_
* Glen Mailer
* Guillaume de Bure
* Ingo Weinhold
* Ismael Juma
* Iulian Udrea
* Ivar Smolin
* Jakub Wilk
* James Geiger
* Jérôme Carretero
* Johann Schmitz
* Jeff Dagenais
* Justin Lecher
* Karl Bielefeldt
* Karthik Manamcheri
* Kelvie Wong
* Kerrick Staley
* Kevin Kofler
* Leho Kraav
* Libor Jelinek
* Liviu Cristian Mirea-Ghiban
* Maciej Filipiak
* Mahmoud Hossam
* Maicon D. Filippsen
* Marco Costalba
* Markus Heidelberg
* Maarten Nieber
* Matěj Šmíd
* Matthew Levine
* Michael Geddes
* Michael Homer
* Minarto Margoliono
* Nicolas Dietrich
* OmegaPhil (Omega Weapon)
* Owen Healy
* Paolo G. Giarrusso
* Paul Hildebrandt
* Peter Júnoš
* Rustam Safin
* Samsul Ma'arif
* Sergey Leschina
* Srinivasa Nallapati
* Stanisław Halik
* Stefan Naewe
* Steffen Prohaska
* Sven Claussner
* Taylor Braun-Jones
* Thomas Kluyver
* Ugo Riboni
* Uri Okrent
* Ｖ字龍 (Vdragon)
* Virgil Dupras
* Vitor Lobo
* Zhang Han
